/*
 This mod is a mod that overrides the symbol Inventory$getContainerSize and returns it to 255
 
 You can find mcpe's symbols by loading the decrypted binary file into IDA
 
 I'll explain every line of code in this file for you
 
 
 */


#include <substrate.h>
// This includes the substrate header file, so we can use MSHookFunction and MSFindSymbol. This is required by all mods

int (*old_Inventory$getContainerSize)(); // This defines the original Inventory$getContainerSize, just incase we need it

int Inventory$getContainerSize() {
// This is the declared function. You can add almost any code here, as long as it returns an int
     return 255; // This sets the inventory container size to 255. You can modify this to what even number you like
}




MSInitialize {
    // MSInitialize starts at runtime. We hook the function at this time

MSHookFunction(((int*)MSFindSymbol(NULL, "__ZNK9Inventory16getContainerSizeEv")),(int*)Inventory$getContainerSize,(int**)&old_Inventory$getContainerSize);
    // Here we hook the function. You'll see MSFindSymbol using a weird string (__ZNK9Inventory16getContainerSizeEv). This is the mangled symbol. IDA can automatically demangle symbols, but you need the mangled version to hook the function. Mangled function names can be found under the demangled name in IDA. You'll see the 2 other parts, after the mangled symbols (Inventory$getContainerSize and old_Inventory$getContainerSize). You can name it whatever, but make sure it is the same name as the ones above (int Inventory$getContainerSize() and int (*old_Inventory$getContainerSize)()) else your code will fail to compile


}