/*
 
 This mod won't compile with MCPE Modder because of clang issues with std::string. You'll need a mac with theos installed to compile this
 
 
 */




#include <substrate.h> // This includes the substrate header file, so we can use MSHookFunction and MSFindSymbol. This is required by all mods

#include <string> // This includes the string header, so we can uses strings like "Hi there!"


void (*old_Gui$$addMessage)(void* arg0, std::string arg1, std::string arg2, int arg3);
// This defines the original Gui$$addMessage, just incase we need it


void Gui$$addMessage(void* arg0, std::string arg1, std::string arg2, int arg3) {
// This is the declared function. Since this is a void, we don't return anything, unlike the other mod examples
    
    std::string msg = "Overriding message in chat!"; // This defines msg as a string which says "Overriding message in chat!"
    
    old_Gui$$addMessage(arg0, arg1, msg, arg3); // This calls the original function with the new message
    
}




MSInitialize {
// MSInitialize starts at runtime. We hook the function at this time
    
    MSHookFunction(((void*)MSFindSymbol(NULL, "__ZN3Gui10addMessageERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEES8_i")),(void*)Gui$$addMessage,(void**)&old_Gui$$addMessage); // Hooks the function. You should know by now what this does if you looked at the other example mods
    
    
    
}