#include <substrate.h> // imports substrate header


int (*OLD_FUNCTION_NAME)(); // defines the original function



int FUNCTION_NAME() {
// declared function
    return 0;
}


MSInitialize {
/*
 This is where you put all of your hooks
 
 For example:
    MSHookFunction(((int*)MSFindSymbol(NULL, "MANGLED_SYMBOL_NAME")),(int*)FUNCTION_NAME,(int**)&OLD_FUNCTION_NAME);
 
 Look at example mods for help
    
    
    */
}